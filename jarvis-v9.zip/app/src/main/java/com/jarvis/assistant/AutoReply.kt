package com.jarvis.assistant

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Gelen WhatsApp / Instagram mesajlarına kullanıcı adına cevap.
 * Mesajı bildirimden okur, Gemini ile taslak yazar, bildirimdeki "Yanıtla" düğmesiyle gönderir.
 *  - ASK : her taslak sesli olarak onaya sunulur.
 *  - AUTO: güvenilen kişilere otomatik gider, diğerlerinde onay istenir.
 */
object AutoReply {
    enum class Mode { OFF, ASK, AUTO }

    class Draft(
        val key: String,
        val platform: String,
        val contact: String,
        val incoming: String,
        var text: String,
        val action: Notification.Action
    )

    private val TR = Locale("tr", "TR")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var prefs: SharedPreferences? = null

    /** ASK modunda (veya güvenilmeyen kişide) taslak hazır olunca Controller burada onay ister. */
    @Volatile var onDraft: ((Draft) -> Unit)? = null
    /** Cevaplanmayan ama kullanıcının bilmesi gereken mesajlar için kısa sesli not. */
    @Volatile var onNotice: ((String) -> Unit)? = null

    private val history = ConcurrentHashMap<String, CopyOnWriteArrayList<Negotiation.Turn>>()
    private val lastSeen = ConcurrentHashMap<String, String>()
    private val sentTimes = ConcurrentHashMap<String, CopyOnWriteArrayList<Long>>()
    private val mutedUntil = ConcurrentHashMap<String, Long>()

    // Kodla uygulanan güvenlik ağı: model ne derse desin, bunlar geçerli.
    private val SENSITIVE_IN = Regex(
        "(iban|\\btr\\d{2}|şifre|sifre|parola|doğrulama|dogrulama|\\bkodu?\\b|\\botp\\b|kapora|havale|\\beft\\b|ödeme|odeme|borç|borc|kredi kart|\\d{6,}|https?://|www\\.)"
    )
    private val UNSAFE_OUT = Regex("(iban|\\btr\\d{2}|\\d{8,}|https?://|www\\.)")

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("jarvis_auto", Context.MODE_PRIVATE)
    }

    // ------------------------------------------------------------ ayarlar
    var mode: Mode
        get() = runCatching { Mode.valueOf(prefs?.getString("mode", "OFF") ?: "OFF") }.getOrDefault(Mode.OFF)
        set(v) { prefs?.edit()?.putString("mode", v.name)?.apply() }

    var apps: Set<String>
        get() = prefs?.getStringSet("apps", null)?.toSet() ?: setOf("whatsapp", "instagram")
        set(v) { prefs?.edit()?.putStringSet("apps", v)?.apply() }

    var style: String
        get() = prefs?.getString("style", "") ?: ""
        set(v) { prefs?.edit()?.putString("style", v.take(200))?.apply() }

    /** Otomatik giden mesajın sonuna "(otomatik yanıt)" eklenir. */
    var tag: Boolean
        get() = prefs?.getBoolean("tag", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("tag", v)?.apply() }

    val allowed: Set<String>
        get() = prefs?.getStringSet("allow", null)?.toSet() ?: emptySet()

    private fun norm(s: String) = s.lowercase(TR).trim()
    private fun same(a: String, b: String) = a == b || (a.length >= 3 && b.length >= 3 && (a.contains(b) || b.contains(a)))

    fun allow(name: String, on: Boolean) {
        val n = norm(name)
        if (n.isEmpty()) return
        val s = allowed.toMutableSet()
        if (on) s.add(n) else s.removeAll { same(it, n) }
        prefs?.edit()?.putStringSet("allow", s)?.apply()
    }

    fun isAllowed(contact: String): Boolean {
        val c = norm(contact)
        return allowed.any { same(c, it) }
    }

    fun turns(key: String): List<Negotiation.Turn> = history[key]?.toList() ?: emptyList()

    // ------------------------------------------------------------ bildirim işleme
    private fun platformOf(pkg: String): String? = when (pkg) {
        "com.whatsapp", "com.whatsapp.w4b" -> "whatsapp"
        "com.instagram.android" -> "instagram"
        else -> null
    }

    @Suppress("DEPRECATION")
    private fun lastIncoming(ex: Bundle): Pair<String, Long>? {
        val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null && arr.isNotEmpty()) {
            val m = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr).lastOrNull()
            if (m != null) {
                val who = m.sender?.toString()?.lowercase(TR)
                if (who == "you" || who == "sen") return null // kendi yazdığımız mesaj
                val t = m.text?.toString()?.trim()
                if (!t.isNullOrEmpty()) return t to m.timestamp
            }
        }
        val t = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: return null
        return if (t.isEmpty()) null else t to 0L
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val acts = n.actions ?: return null
        val withInput = acts.filter { it.remoteInputs?.isNotEmpty() == true }
        if (Build.VERSION.SDK_INT >= 28) {
            withInput.firstOrNull { it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY }?.let { return it }
        }
        return withInput.firstOrNull()
    }

    fun handle(ctx: Context, sbn: StatusBarNotification) {
        val platform = platformOf(sbn.packageName) ?: return
        val m = mode
        if (m == Mode.OFF || platform !in apps) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
        if (title.isEmpty()) return
        // Gruplar, kayıtsız numaralar ve devam eden WhatsApp pazarlığı atlanır
        if (ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION) || ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) != null) return
        if (title.count { it.isDigit() } >= 7) return
        if (Negotiation.active && Negotiation.matches(title)) return

        val (text, ts) = lastIncoming(ex) ?: return
        val key = "$platform|${norm(title)}"
        val now = System.currentTimeMillis()
        if (now < (mutedUntil[key] ?: 0L)) return            // az önce biz yazdık, bildirim güncellendi
        val sig = "$text|$ts"
        if (lastSeen.put(key, sig) == sig) return             // aynı mesaj tekrar bildirildi
        val action = findReplyAction(n) ?: return             // Yanıtla düğmesi yoksa atla

        val times = sentTimes.getOrPut(key) { CopyOnWriteArrayList() }
        times.removeAll { now - it > 10 * 60_000L }
        if (times.size >= 3) return                           // 10 dakikada en çok 3 otomatik cevap (bot döngüsü koruması)

        val hist = history.getOrPut(key) { CopyOnWriteArrayList() }
        hist.add(Negotiation.Turn(false, text))
        while (hist.size > 12) hist.removeAt(0)

        if (SENSITIVE_IN.containsMatchIn(text.lowercase(TR))) {
            onNotice?.invoke("$title $platform üzerinden para, kod ya da bağlantı içeren bir mesaj yazdı, cevaplamadım: ${text.take(100)}")
            return
        }

        scope.launch {
            val r = GeminiClient.autoReply(style, platform, title, hist.toList(), null)
            val out = r.text.trim().trim('"')
            val up = out.uppercase(Locale.ROOT)
            when {
                !r.ok || out.isBlank() || up.startsWith("SKIP") -> return@launch
                up.startsWith("ASK_USER") -> {
                    onNotice?.invoke("$title $platform üzerinden yazdı, bunu sizin cevaplamanız gerekebilir: ${text.take(100)}")
                    return@launch
                }
                UNSAFE_OUT.containsMatchIn(out.lowercase(TR)) -> {
                    onNotice?.invoke("$title için hazırladığım cevap güvenli görünmediği için göndermedim.")
                    return@launch
                }
            }
            if (m == Mode.AUTO && isAllowed(title)) {
                val finalText = if (tag) "$out (otomatik yanıt)" else out
                if (sendReply(ctx, action, finalText)) {
                    hist.add(Negotiation.Turn(true, finalText))
                    times.add(System.currentTimeMillis())
                    mutedUntil[key] = System.currentTimeMillis() + 8000
                }
            } else {
                onDraft?.invoke(Draft(key, platform, title, text, out, action))
            }
        }
    }

    // ------------------------------------------------------------ gönderme
    /** Kullanıcı onayladıktan sonra taslağı gönderir; sesli söylenecek cevabı döner. */
    fun send(ctx: Context, d: Draft, text: String): String {
        val ok = sendReply(ctx, d.action, text)
        if (ok) {
            history[d.key]?.add(Negotiation.Turn(true, text))
            mutedUntil[d.key] = System.currentTimeMillis() + 8000
        }
        return if (ok) "${d.contact} kişisine gönderdim efendim." else "Gönderemedim efendim, bildirim kapanmış olabilir."
    }

    private fun sendReply(ctx: Context, action: Notification.Action, text: String): Boolean {
        val inputs = action.remoteInputs ?: return false
        if (inputs.isEmpty()) return false
        return try {
            val intent = Intent()
            val bundle = Bundle()
            for (ri in inputs) bundle.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            action.actionIntent.send(ctx, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        } catch (e: Exception) {
            false
        }
    }
}
