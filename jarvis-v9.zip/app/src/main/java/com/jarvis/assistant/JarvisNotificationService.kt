package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * 1) Pazarlık sırasında yalnız o kişiden gelen WhatsApp bildirimlerini okur.
 * 2) Otomatik cevap açıksa gelen WhatsApp / Instagram mesajlarını AutoReply'a verir.
 */
class JarvisNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val n = sbn.notification ?: return

        if (Negotiation.active && sbn.packageName == "com.whatsapp" && (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0) {
            val ex = n.extras
            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            val text = ex?.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
            if (title != null && !text.isNullOrEmpty() && Negotiation.matches(title)) {
                Negotiation.onIncoming?.invoke(text)
                return
            }
        }

        AutoReply.init(applicationContext)
        AutoReply.handle(applicationContext, sbn)
    }
}
