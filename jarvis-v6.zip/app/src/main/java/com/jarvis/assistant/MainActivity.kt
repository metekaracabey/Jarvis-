package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class JState { SLEEP, LISTENING, THINKING, SPEAKING }
data class Msg(val text: String, val fromUser: Boolean)

class Controller(private val ctx: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val actions = Actions(ctx)
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var active = false
    private var speakStart = 0L
    private var loudCount = 0

    var state by mutableStateOf(JState.LISTENING)
    var partial by mutableStateOf("")
    var level by mutableStateOf(0f)
    val messages = mutableStateListOf<Msg>()

    private val restartRunnable = Runnable { listen() }

    private val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onRmsChanged(v: Float) {
            level = level * 0.7f + (v.coerceIn(0f, 10f) / 10f) * 0.3f
            // Konuşurken araya girme: yüksek ses gelirse susar
            if (state == JState.SPEAKING && SystemClock.elapsedRealtime() - speakStart > 700) {
                if (v > 8.5f) loudCount++ else loudCount = 0
                if (loudCount >= 3) {
                    tts?.stop()
                    state = JState.LISTENING
                    loudCount = 0
                }
            }
        }

        override fun onError(e: Int) {
            partial = ""
            if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { active = false; return }
            restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == SpeechRecognizer.ERROR_CLIENT) 700 else 250)
        }

        override fun onPartialResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (state == JState.SLEEP) {
                if (isWake(t)) wake()
            } else if (state == JState.LISTENING) {
                partial = t
            }
        }

        override fun onResults(b: Bundle?) {
            partial = ""
            handle(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            restart(250)
        }
    }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { onSpeechDone() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { onSpeechDone() } }
                })
            }
        }
    }

    // ---- sürekli dinleme döngüsü ----
    fun startLoop() {
        if (active) return
        active = true
        muteBeep(true)
        restart(100)
    }

    fun stopLoop() {
        active = false
        main.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        muteBeep(false)
    }

    private fun restart(ms: Long) {
        main.removeCallbacks(restartRunnable)
        if (active) main.postDelayed(restartRunnable, ms)
    }

    private fun listen() {
        if (!active) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(listener)
        }
        recognizer?.startListening(recIntent)
    }

    private fun muteBeep(mute: Boolean) {
        try {
            val dir = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            audio.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, dir, 0)
            audio.adjustStreamVolume(AudioManager.STREAM_SYSTEM, dir, 0)
        } catch (_: Exception) {}
    }

    // ---- komut işleme ----
    private fun isWake(t: String): Boolean {
        val s = t.lowercase(Locale.ROOT)
        return listOf("jarvis", "jarvıs", "carvis", "carvıs", "çarvis", "jervis", "cervis", "harvis")
            .any { s.contains(it) }
    }

    private fun isSleepCommand(t: String): Boolean {
        val s = t.lowercase(Locale.ROOT)
        return s.contains("uyku modu") || s.contains("kendini kapat") ||
            s.contains("jarvis uyu") || s.contains("uyu jarvis")
    }

    private fun handle(raw: String?) {
        val text = raw?.trim().orEmpty()
        if (text.isEmpty()) return
        when (state) {
            JState.SLEEP -> if (isWake(text)) wake()
            JState.LISTENING -> {
                if (isSleepCommand(text)) { goToSleep("İyi geceler efendim."); return }
                send(text)
            }
            else -> {}
        }
    }

    fun toggleSleep() {
        if (state == JState.SLEEP) wake() else goToSleep(null)
    }

    private fun goToSleep(bye: String?) {
        tts?.stop()
        partial = ""
        state = JState.SLEEP
        if (bye != null) tts?.speak(bye, TextToSpeech.QUEUE_FLUSH, null, "bye")
    }

    private fun wake() {
        speak("Buradayım efendim.")
    }

    private fun speak(text: String) {
        state = JState.SPEAKING
        speakStart = SystemClock.elapsedRealtime()
        loudCount = 0
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun onSpeechDone() {
        if (state == JState.SPEAKING) state = JState.LISTENING
        // kendi sesimizin yankısı sonuç olarak gelmesin diye oturumu sıfırla
        recognizer?.destroy()
        recognizer = null
        restart(300)
    }

    fun send(text: String) {
        if (state == JState.SLEEP || state == JState.THINKING) return
        tts?.stop()
        messages.add(Msg(text, true))
        history.add("user" to text)
        state = JState.THINKING
        scope.launch {
            val reply = try {
                GeminiClient.chat(history)
            } catch (e: Exception) {
                GeminiClient.Reply("Bağlantı sorunu oluştu efendim.", emptyList())
            }
            var spoken = reply.text
            if (reply.calls.isNotEmpty()) {
                spoken = reply.calls.map { (n, a) ->
                    try { actions.run(n, a) } catch (e: Exception) { "Bu işlemi yapamadım efendim." }
                }.joinToString(" ")
            }
            if (spoken.isBlank()) spoken = "Anlayamadım efendim."
            history.add("model" to spoken)
            messages.add(Msg(spoken, false))
            if (state == JState.THINKING) speak(spoken)
        }
    }

    fun release() {
        stopLoop()
        scope.cancel()
        tts?.shutdown()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var jarvis: Controller

    private val allPerms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_FINE_LOCATION
    )
    private var asked = false

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) jarvis.startLoop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        jarvis = Controller(applicationContext)
        setContent { JarvisApp(jarvis) }
    }

    override fun onStart() {
        super.onStart()
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micOk) jarvis.startLoop()
        val missing = allPerms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty() && !asked) {
            asked = true
            permLauncher.launch(missing.toTypedArray())
        }
    }

    override fun onStop() {
        jarvis.stopLoop()
        super.onStop()
    }

    override fun onDestroy() {
        jarvis.release()
        super.onDestroy()
    }
}

// ------------------------------------------------------------------ UI

private val Bg = Color(0xFF03060C)
private val Cyan = Color(0xFF3DDCFF)
private val Green = Color(0xFF4DFFB0)
private val Amber = Color(0xFFFFB347)
private val Ice = Color(0xFFBFEFFF)
private val Grey = Color(0xFF4A5568)
private val Standby = Color(0xFFFF4D4D)

private fun stateColor(s: JState) = when (s) {
    JState.LISTENING -> Cyan
    JState.THINKING -> Amber
    JState.SPEAKING -> Green
    JState.SLEEP -> Grey
}

private fun stateLabel(s: JState) = when (s) {
    JState.LISTENING -> "DİNLİYORUM"
    JState.THINKING -> "İŞLENİYOR"
    JState.SPEAKING -> "KONUŞUYORUM"
    JState.SLEEP -> "UYKU MODU · DOKUN VEYA \"JARVIS\" DE"
}

@Composable
fun JarvisApp(j: Controller) {
    val awake = j.state != JState.SLEEP
    val power = remember { Animatable(0f) }
    LaunchedEffect(awake) {
        power.animateTo(if (awake) 1f else 0f, tween(if (awake) 1200 else 700, easing = LinearEasing))
    }
    val p = power.value
    val color by animateColorAsState(stateColor(j.state), tween(450), label = "c")

    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(j.messages.size) {
        if (j.messages.isNotEmpty()) listState.animateScrollToItem(j.messages.size - 1)
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        HudBackground(p)
        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp).alpha(0.4f + 0.6f * p),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("J.A.R.V.I.S", color = color, fontFamily = FontFamily.Monospace,
                    fontSize = 15.sp, letterSpacing = 4.sp)
                Clock(color)
            }

            Box(
                Modifier
                    .padding(top = 6.dp)
                    .size(300.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        j.toggleSleep()
                    },
                contentAlignment = Alignment.Center
            ) {
                Reactor(j.state, p, j.level, color)
            }

            Text(
                stateLabel(j.state), color = color, fontFamily = FontFamily.Monospace,
                fontSize = 12.sp, letterSpacing = 3.sp, textAlign = TextAlign.Center
            )
            Waveform(j.level, color, p)
            Text(
                j.partial, color = Color(0xFF8FA3B8), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().height(20.dp).alpha(p)
            )

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().alpha(p),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(j.messages) { m ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Text(
                            m.text,
                            color = if (m.fromUser) Ice else Color(0xFFE6F6FF),
                            fontSize = 14.sp,
                            modifier = Modifier
                                .widthIn(max = 300.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (m.fromUser) Color(0xFF0E2A3F) else Color(0xFF0B1626))
                                .border(1.dp, if (m.fromUser) Cyan.copy(alpha = 0.6f) else Color(0xFF1E3A5F), RoundedCornerShape(10.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp).alpha(p),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    enabled = awake,
                    placeholder = { Text("Komut yaz…", color = Grey) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF1E3A5F),
                        cursorColor = Cyan
                    )
                )
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, Cyan, CircleShape)
                        .clickable {
                            if (awake && input.isNotBlank()) { j.send(input.trim()); input = "" }
                        },
                    contentAlignment = Alignment.Center
                ) { Text("↑", color = Cyan, fontSize = 20.sp) }
            }
        }
    }
}

@Composable
fun Clock(color: Color) {
    var now by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        while (true) { now = f.format(Date()); delay(1000) }
    }
    Text(now, color = color, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
}

@Composable
fun HudBackground(p: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val step = 36.dp.toPx()
        val gridColor = Cyan.copy(alpha = 0.05f * p)
        var x = 0f
        while (x < size.width) { drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), 1f); x += step }
        var y = 0f
        while (y < size.height) { drawLine(gridColor, Offset(0f, y), Offset(size.width, y), 1f); y += step }

        val l = 22.dp.toPx(); val m = 8.dp.toPx(); val sw = 2.dp.toPx()
        val bc = Cyan.copy(alpha = 0.45f * (0.3f + 0.7f * p))
        val w = size.width; val h = size.height
        drawLine(bc, Offset(m, m), Offset(m + l, m), sw); drawLine(bc, Offset(m, m), Offset(m, m + l), sw)
        drawLine(bc, Offset(w - m, m), Offset(w - m - l, m), sw); drawLine(bc, Offset(w - m, m), Offset(w - m, m + l), sw)
        drawLine(bc, Offset(m, h - m), Offset(m + l, h - m), sw); drawLine(bc, Offset(m, h - m), Offset(m, h - m - l), sw)
        drawLine(bc, Offset(w - m, h - m), Offset(w - m - l, h - m), sw); drawLine(bc, Offset(w - m, h - m), Offset(w - m, h - m - l), sw)
    }
}

@Composable
fun Waveform(level: Float, color: Color, p: Float) {
    val t = rememberInfiniteTransition(label = "w")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "ph"
    )
    Canvas(Modifier.fillMaxWidth().height(34.dp)) {
        val n = 41
        val gap = size.width / n
        for (i in 0 until n) {
            val env = 1f - abs(i - n / 2f) / (n / 2f)
            val amp = (0.10f + level * 0.9f) * env * (0.5f + 0.5f * abs(sin(phase + i * 0.45f)))
            val h = (0.05f + amp) * size.height
            val x = gap * (i + 0.5f)
            drawLine(
                color.copy(alpha = 0.8f * p),
                Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun Reactor(state: JState, p: Float, level: Float, color: Color) {
    val t = rememberInfiniteTransition(label = "reactor")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (state == JState.THINKING) 3500 else 14000, easing = LinearEasing)),
        label = "spin"
    )
    val spin2 by t.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(if (state == JState.THINKING) 2000 else 8000, easing = LinearEasing)),
        label = "spin2"
    )
    val breathe by t.animateFloat(
        initialValue = 0.96f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            tween(if (state == JState.SPEAKING) 600 else 2200, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "breathe"
    )

    Canvas(Modifier.fillMaxSize()) {
        val c = center
        val r = size.minDimension / 2 * 0.98f

        // TV kapanma / açılma: önce dikey çökme, sonra yatay daralma, sonra nokta
        val sy = if (p >= 0.5f) 0.012f + 0.988f * ((p - 0.5f) / 0.5f) else 0.012f
        val sx = if (p >= 0.5f) 1f else if (p > 0.12f) (p - 0.12f) / 0.38f else 0f

        if (p > 0.12f) {
            withTransform({ scale(scaleX = sx.coerceAtLeast(0.001f), scaleY = sy, pivot = c) }) {
                val lv = level.coerceIn(0f, 1f)

                // dış parıltı
                drawCircle(
                    Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent), c, r),
                    radius = r * breathe * (1f + lv * 0.12f), center = c
                )
                // tik halkası
                for (i in 0 until 72) {
                    val a = Math.toRadians((spin + i * 5f).toDouble())
                    val inner = r * 0.90f
                    val outer = r * (if (i % 6 == 0) 0.98f else 0.94f)
                    val dx = cos(a).toFloat(); val dy = sin(a).toFloat()
                    drawLine(
                        color.copy(alpha = if (i % 6 == 0) 0.85f else 0.35f),
                        Offset(c.x + dx * inner, c.y + dy * inner),
                        Offset(c.x + dx * outer, c.y + dy * outer),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
                // ince halka
                drawCircle(color.copy(alpha = 0.35f), r * 0.86f, c, style = Stroke(1.5.dp.toPx()))
                // 3 parçalı kalın yay
                for (k in 0 until 3) {
                    drawArc(
                        color, startAngle = spin2 + k * 120f, sweepAngle = 70f, useCenter = false,
                        topLeft = Offset(c.x - r * 0.78f, c.y - r * 0.78f),
                        size = Size(r * 1.56f, r * 1.56f),
                        style = Stroke(5.dp.toPx(), cap = StrokeCap.Butt)
                    )
                }
                // kesikli iç halka
                for (k in 0 until 12) {
                    drawArc(
                        color.copy(alpha = 0.55f), startAngle = spin * 1.5f + k * 30f, sweepAngle = 18f,
                        useCenter = false,
                        topLeft = Offset(c.x - r * 0.62f, c.y - r * 0.62f),
                        size = Size(r * 1.24f, r * 1.24f),
                        style = Stroke(2.dp.toPx())
                    )
                }
                // ses seviyesine tepki veren halka
                drawCircle(color.copy(alpha = 0.8f), r * (0.50f + lv * 0.10f), c, style = Stroke(2.dp.toPx()))
                // çekirdek
                val coreR = r * 0.40f * breathe * (1f + lv * 0.25f)
                drawCircle(
                    Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0.1f)), c, coreR),
                    radius = coreR, center = c
                )
            }
        }

        // CRT çizgisi ve nokta
        if (p < 0.97f) {
            val lineA = if (p > 0.12f) 1f else (p / 0.12f).coerceIn(0f, 1f)
            val fade = if (p >= 0.5f) ((1f - p) * 2f).coerceIn(0f, 1f) else 1f
            val half = r * sx
            if (half > 1f && p > 0.12f) {
                drawLine(color.copy(alpha = 0.25f * fade), Offset(c.x - half, c.y), Offset(c.x + half, c.y), 12.dp.toPx(), StrokeCap.Round)
                drawLine(Color.White.copy(alpha = fade), Offset(c.x - half, c.y), Offset(c.x + half, c.y), 3.dp.toPx(), StrokeCap.Round)
            }
            if (p < 0.5f && p > 0.001f) {
                drawCircle(color.copy(alpha = 0.3f * lineA), 14.dp.toPx(), c)
                drawCircle(Color.White.copy(alpha = lineA), 4.dp.toPx(), c)
            }
        }

        // bekleme ışığı (TV standby LED)
        if (p < 0.02f) {
            val a = 0.3f + (breathe - 0.96f) * 6f
            drawCircle(Standby.copy(alpha = a.coerceIn(0.2f, 0.9f)), 5.dp.toPx(), c)
        }
    }
}
