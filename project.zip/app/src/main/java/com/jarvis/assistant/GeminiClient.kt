package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    private const val MODEL = "gemini-2.5-flash"

    private const val SYSTEM = "Sen JARVIS adlı kişisel yapay zeka asistanısın. " +
        "Türkçe konuş. Cevapların sesli okunacak: kısa, net, doğal ve hafif zeki bir " +
        "tonda ol (en fazla 2-3 cümle). Liste, madde işareti, emoji ve markdown kullanma. " +
        "Kullanıcıya 'efendim' diye hitap edebilirsin ama abartma."

    /** history: (rol, metin) çiftleri. rol = "user" veya "model" */
    suspend fun chat(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            return@withContext "API anahtarı bulunamadı. GitHub secret olarak GEMINI_API_KEY eklenmeli."
        }
        val contents = JSONArray()
        history.takeLast(20).forEach { (role, text) ->
            contents.put(JSONObject()
                .put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject()
                .put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject()
                .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Gemini hatası ($code): " + text.take(200))

        JSONObject(text)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
            .getJSONObject(0).getString("text").trim()
    }
}
