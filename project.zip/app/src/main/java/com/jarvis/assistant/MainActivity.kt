package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

enum class JState { IDLE, LISTENING, THINKING, SPEAKING, SLEEP }
data class Msg(val text: String, val fromUser: Boolean)

class Controller(private val ctx: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    var state by mutableStateOf(JState.IDLE)
    var partial by mutableStateOf("")
    val messages = mutableStateListOf<Msg>()

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { if (state == JState.SPEAKING) state = JState.IDLE } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { if (state == JState.SPEAKING) state = JState.IDLE } }
                })
            }
        }
    }

    fun onMicPressed() {
        when (state) {
            JState.SLEEP, JState.THINKING -> {}
            JState.LISTENING -> recognizer?.stopListening()
            JState.SPEAKING, JState.IDLE -> startListening()
        }
    }

    fun toggleSleep() {
        if (state == JState.SLEEP) {
            state = JState.IDLE
        } else {
            tts?.stop()
            recognizer?.destroy()
            recognizer = null
            partial = ""
            state = JState.SLEEP
        }
    }

    private fun startListening() {
        tts?.stop()
        recognizer?.destroy()
        partial = ""
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) {
                    partial = ""
                    if (state == JState.LISTENING) state = JState.IDLE
                }
                override fun onPartialResults(b: Bundle?) {
                    partial = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                }
                override fun onResults(b: Bundle?) {
                    partial = ""
                    val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) state = JState.IDLE else send(text)
                }
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        state = JState.LISTENING
        recognizer?.startListening(intent)
    }

    fun send(text: String) {
        if (state == JState.SLEEP) return
        tts?.stop()
        messages.add(Msg(text, true))
        history.add("user" to text)
        state = JState.THINKING
        scope.launch {
            val reply = try {
                GeminiClient.chat(history)
            } catch (e: Exception) {
                "Bağlantı sorunu: ${e.message}"
            }
            history.add("model" to reply)
            messages.add(Msg(reply, false))
            if (state == JState.THINKING) {
                state = JState.SPEAKING
                tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
            }
        }
    }

    fun release() {
        scope.cancel()
        recognizer?.destroy()
        tts?.shutdown()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var jarvis: Controller
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        jarvis = Controller(applicationContext)
        setContent { JarvisApp(jarvis) }
    }
    override fun onDestroy() {
        jarvis.release()
        super.onDestroy()
    }
}

private val Bg1 = Color(0xFF05080F)
private val Bg2 = Color(0xFF0B1626)
private val Cyan = Color(0xFF3DDCFF)
private val Green = Color(0xFF4DFFB0)
private val Amber = Color(0xFFFFB347)
private val Ice = Color(0xFFBFEFFF)
private val Grey = Color(0xFF4A5568)

private fun stateColor(s: JState) = when (s) {
    JState.IDLE -> Cyan
    JState.LISTENING -> Green
    JState.THINKING -> Amber
    JState.SPEAKING -> Ice
    JState.SLEEP -> Grey
}

private fun stateLabel(s: JState) = when (s) {
    JState.IDLE -> "Hazırım"
    JState.LISTENING -> "Dinliyorum"
    JState.THINKING -> "Düşünüyorum"
    JState.SPEAKING -> "Konuşuyorum"
    JState.SLEEP -> "Uyku modu"
}

@Composable
fun JarvisApp(j: Controller) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) j.onMicPressed()
    }
    fun mic() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) j.onMicPressed() else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(j.messages.size) {
        if (j.messages.isNotEmpty()) listState.animateScrollToItem(j.messages.size - 1)
    }
    val color = stateColor(j.state)

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Bg1, Bg2)))
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "JARVIS", color = color, fontSize = 22.sp, fontWeight = FontWeight.Light,
            letterSpacing = 8.sp, modifier = Modifier.padding(top = 16.dp)
        )
        Orb(j.state)
        Text(stateLabel(j.state), color = color, fontSize = 15.sp)
        Text(
            j.partial, color = Color(0xFF8FA3B8), fontSize = 14.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp).fillMaxWidth()
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(j.messages) { m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Text(
                        m.text,
                        color = if (m.fromUser) Color(0xFF05080F) else Color(0xFFE6F6FF),
                        fontSize = 15.sp,
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (m.fromUser) Cyan else Color(0xFF12243A))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Yaz…", color = Grey) },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF1E3A5F),
                    cursorColor = Cyan
                )
            )
            RoundButton("Gönder", 56, Cyan) {
                if (input.isNotBlank()) { j.send(input.trim()); input = "" }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(if (j.state == JState.SLEEP) "Uyan" else "Uyku", 64, Grey) { j.toggleSleep() }
            RoundButton(
                when (j.state) {
                    JState.LISTENING -> "Bitir"
                    JState.SPEAKING -> "Sus"
                    else -> "Konuş"
                }, 92, color
            ) { mic() }
        }
    }
}

@Composable
fun RoundButton(label: String, sizeDp: Int, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(color.copy(alpha = 0.28f), color.copy(alpha = 0.06f))))
            .border(2.dp, color, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = color, fontSize = if (sizeDp > 80) 16.sp else 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Orb(state: JState) {
    val t = rememberInfiniteTransition(label = "orb")
    val ms = when (state) {
        JState.SPEAKING -> 500
        JState.LISTENING -> 800
        JState.THINKING -> 1100
        JState.IDLE -> 2200
        JState.SLEEP -> 4000
    }
    val pulse by t.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(if (state == JState.THINKING) 1500 else 9000, easing = LinearEasing)
        ),
        label = "spin"
    )
    val color = stateColor(state)

    Canvas(Modifier.size(250.dp).padding(8.dp)) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.40f), Color.Transparent), c, r),
            radius = r * pulse, center = c
        )
        drawCircle(color.copy(alpha = 0.5f), radius = r * 0.78f, center = c, style = Stroke(2.dp.toPx()))
        drawArc(
            color, startAngle = spin, sweepAngle = 100f, useCenter = false,
            topLeft = Offset(c.x - r * 0.88f, c.y - r * 0.88f),
            size = Size(r * 1.76f, r * 1.76f), style = Stroke(4.dp.toPx())
        )
        drawArc(
            color.copy(alpha = 0.6f), startAngle = -spin * 1.6f, sweepAngle = 60f, useCenter = false,
            topLeft = Offset(c.x - r * 0.68f, c.y - r * 0.68f),
            size = Size(r * 1.36f, r * 1.36f), style = Stroke(3.dp.toPx())
        )
        drawCircle(
            Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0.1f)), c, r * 0.5f * pulse),
            radius = r * 0.5f * pulse, center = c
        )
    }
}
