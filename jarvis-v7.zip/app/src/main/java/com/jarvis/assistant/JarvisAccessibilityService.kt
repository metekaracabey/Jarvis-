package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Jarvis bir WhatsApp mesajı istediğinde 20 saniyeliğine "silahlanır"; sadece o sürede Gönder'e basar. */
object SendBridge {
    @Volatile var armedUntil = 0L
    @Volatile var serviceRunning = false
    fun arm() { armedUntil = SystemClock.elapsedRealtime() + 20000 }
    fun armed() = SystemClock.elapsedRealtime() < armedUntil
}

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { SendBridge.serviceRunning = true }

    override fun onUnbind(intent: Intent?): Boolean {
        SendBridge.serviceRunning = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!SendBridge.armed()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != "com.whatsapp") return

        for (label in listOf("Gönder", "Send")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                val exact = n.contentDescription?.toString().equals(label, ignoreCase = true) ||
                    n.text?.toString().equals(label, ignoreCase = true)
                if (!exact) continue
                var t: AccessibilityNodeInfo? = n
                while (t != null && !t.isClickable) t = t.parent
                if (t != null) {
                    SendBridge.armedUntil = 0L
                    t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Handler(Looper.getMainLooper()).postDelayed({ backToJarvis() }, 1500)
                    return
                }
            }
        }
    }

    private fun backToJarvis() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (_: Exception) {}
    }
}
