package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Pazarlık sırasında sadece o kişiden gelen WhatsApp bildirimlerini okur. */
class JarvisNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (!Negotiation.active || sbn.packageName != "com.whatsapp") return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: return
        if (text.isEmpty() || !Negotiation.matches(title)) return
        Negotiation.onIncoming?.invoke(text)
    }
}
