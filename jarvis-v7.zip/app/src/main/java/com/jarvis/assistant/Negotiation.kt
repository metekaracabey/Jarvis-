package com.jarvis.assistant

import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/** Aktif WhatsApp pazarlık oturumu. Bildirim servisi ile Controller arasındaki köprü. */
object Negotiation {
    data class Turn(val fromMe: Boolean, val text: String)

    @Volatile var active = false
    @Volatile var contact = ""      // WhatsApp'ta görünen ad
    @Volatile var waNumber = ""     // uluslararası biçimde rakamlar
    @Volatile var brief = ""        // ilan bilgisi, hedef ve sınırlar
    val turns = CopyOnWriteArrayList<Turn>()
    @Volatile var onIncoming: ((String) -> Unit)? = null

    fun start(who: String, number: String, b: String) {
        contact = who; waNumber = number; brief = b
        turns.clear()
        active = true
    }

    fun stop() { active = false }

    fun matches(title: String): Boolean {
        val tr = Locale("tr", "TR")
        val t = title.lowercase(tr).trim()
        val c = contact.lowercase(tr).trim()
        if (c.isNotEmpty() && t.length >= 3 && (t.contains(c) || c.contains(t))) return true
        val digits = title.filter { it.isDigit() }
        return waNumber.length >= 10 && digits.length >= 10 && digits.endsWith(waNumber.takeLast(10))
    }
}
