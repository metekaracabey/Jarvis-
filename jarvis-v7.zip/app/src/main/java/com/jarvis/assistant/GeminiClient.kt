package com.jarvis.assistant

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

object GeminiClient {
    // Sırayla denenir: biri yoğunsa veya kapalıysa sonrakine geçilir
    private val MODELS = listOf(
        "gemini-3.5-flash-lite", "gemini-3.1-flash-lite-preview", "gemini-3-flash-preview",
        "gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-3.5-flash"
    )

    @Volatile private var good: String? = null
    private val skipUntil = ConcurrentHashMap<String, Long>()

    private fun order(): List<String> {
        val now = SystemClock.elapsedRealtime()
        val avail = MODELS.filter { (skipUntil[it] ?: 0L) < now }.ifEmpty { MODELS }
        val g = good
        return if (g != null && g in avail) listOf(g) + avail.filter { it != g } else avail
    }

    private fun penalize(model: String, code: Int) {
        val now = SystemClock.elapsedRealtime()
        skipUntil[model] = when (code) {
            404, 400 -> Long.MAX_VALUE      // bu modelde yok / istek uymuyor: oturum boyunca atla
            429 -> now + 60_000             // kota: 1 dk dinlendir
            else -> now + 10_000            // 5xx: kısa süre atla
        }
        if (good == model) good = null
    }

    data class Reply(val text: String, val calls: List<Pair<String, JSONObject>>, val ok: Boolean = true)

    private const val SYSTEM = "Sen JARVIS adlı kişisel yapay zeka asistanısın ve kullanıcının telefonunu kontrol eden araçların var. " +
        "Türkçe konuş. Cevapların sesli okunacak: kısa, net, doğal ve hafif zeki bir tonda ol (en fazla 2-3 cümle). " +
        "Liste, madde işareti, emoji ve markdown kullanma. Kullanıcıya 'efendim' diye hitap edebilirsin ama abartma. " +
        "Kullanıcı bir işlem isterse (arama, mesaj, müzik, uygulama açma, hava durumu, alarm, zamanlayıcı) ilgili aracı MUTLAKA çağır, " +
        "'yapamam' deme. Kişi adlarını rehberde kayıtlı olabileceği yalın biçimde ver ('babama' -> 'babam', 'Ahmet'e' -> 'Ahmet'). " +
        "WhatsApp mesajını kullanıcının ağzından, birinci tekil kişiyle yaz: 'babama neredesin yaz' -> mesaj 'Neredesin?'. " +
        "Kullanıcı WhatsApp üzerinden sesli veya görüntülü arama isterse whatsapp_call, normal arama isterse call_contact aracını kullan. " +
        "Kullanıcı bir ilan için birine WhatsApp'tan pazarlık yaptırmak isterse start_negotiation aracını çağır. brief alanına ilan bilgisini, hedef fiyatı ve en fazla ödeyeceği tavan fiyatı aynen yaz; tavan fiyat veya ilan bilgisi eksikse aracı çağırmadan önce kullanıcıya kısaca sor. opening_message kullanıcının ağzından yazılmış nazik ilk mesajdır. " +
        "Banka ve e-Devlet işlemleri yapma. Araç gerektirmeyen sorularda normal sohbet et."

    private fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    private fun fn(name: String, desc: String, props: JSONObject = JSONObject(), required: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.length() > 0) {
            o.put("parameters", JSONObject()
                .put("type", "object")
                .put("properties", props)
                .put("required", JSONArray(required)))
        }
        return o
    }

    private val TOOLS: JSONArray = JSONArray().put(
        JSONObject().put("functionDeclarations", JSONArray()
            .put(fn("call_contact", "Rehberdeki birini normal telefon (GSM) hattından arar. WhatsApp araması DEĞİLDİR.",
                JSONObject()
                    .put("contact_name", p("string", "Rehberdeki kişi adı, yalın hâl"))
                    .put("speaker", p("boolean", "Hoparlöre alınsın mı")),
                listOf("contact_name")))
            .put(fn("send_whatsapp", "Rehberdeki birine WhatsApp mesajı gönderir.",
                JSONObject()
                    .put("contact_name", p("string", "Rehberdeki kişi adı, yalın hâl"))
                    .put("message", p("string", "Gönderilecek mesaj metni")),
                listOf("contact_name", "message")))
            .put(fn("whatsapp_call", "Rehberdeki birini WhatsApp üzerinden sesli veya görüntülü arar. Kullanıcı 'WhatsApp'tan ara', 'WhatsApp'la ara', 'görüntülü ara', 'görüntülü konuş' derse bunu kullan.",
                JSONObject()
                    .put("contact_name", p("string", "Rehberdeki kişi adı, yalın hâl"))
                    .put("video", p("boolean", "Görüntülü arama ise true, sesli ise false")),
                listOf("contact_name")))
            .put(fn("start_negotiation", "Kullanıcı adına WhatsApp'tan bir ilan için pazarlık görüşmesi başlatır; ilk mesajı gönderir, sonraki cevapları kullanıcı onayıyla yürütür.",
                JSONObject()
                    .put("contact_name", p("string", "Rehberdeki satıcı veya galerici adı, yalın hâl (numara verildiyse boş olabilir)"))
                    .put("phone_number", p("string", "Rehberde kayıtlı değilse satıcının telefon numarası"))
                    .put("brief", p("string", "İlan bilgisi, kullanıcının hedef fiyatı, en fazla ödeyeceği tavan fiyat ve diğer istekleri"))
                    .put("opening_message", p("string", "Satıcıya gidecek ilk mesaj, kullanıcının ağzından, birinci tekil kişiyle")),
                listOf("brief", "opening_message")))
            .put(fn("play_spotify", "Spotify'da şarkı, sanatçı veya çalma listesi açıp çalar. Sadece 'müzik aç' denirse query boş olsun.",
                JSONObject().put("query", p("string", "Aranacak sanatçı veya şarkı"))))
            .put(fn("open_app", "Telefondaki bir uygulamayı açar.",
                JSONObject().put("app_name", p("string", "Uygulamanın adı")), listOf("app_name")))
            .put(fn("get_weather", "Kullanıcının bulunduğu konumun güncel hava durumunu söyler."))
            .put(fn("set_alarm", "Belirli bir saate alarm kurar.",
                JSONObject()
                    .put("hour", p("integer", "Saat, 0-23"))
                    .put("minute", p("integer", "Dakika, 0-59"))
                    .put("label", p("string", "Alarm adı")),
                listOf("hour", "minute")))
            .put(fn("set_timer", "Geri sayım zamanlayıcısı kurar.",
                JSONObject().put("seconds", p("integer", "Toplam süre, saniye")), listOf("seconds")))
            .put(fn("set_speaker", "Devam eden aramada hoparlörü açar veya kapatır.",
                JSONObject().put("on", p("boolean", "Açık mı")), listOf("on")))
            .put(fn("open_accessibility_settings", "Erişilebilirlik ayarlarını açar, WhatsApp otomatik gönderme servisini açmak için."))
        )
    )

    private fun system(): String {
        val now = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", Locale("tr", "TR")).format(Date())
        return "$SYSTEM Şu an tarih ve saat: $now."
    }

    private fun call(model: String, body: String): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun parse(text: String): Reply {
        val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return Reply("", emptyList())
        val sb = StringBuilder()
        val calls = mutableListOf<Pair<String, JSONObject>>()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            part.optJSONObject("functionCall")?.let {
                calls.add(it.getString("name") to (it.optJSONObject("args") ?: JSONObject()))
            }
            if (part.has("text") && !part.optBoolean("thought", false)) sb.append(part.getString("text"))
        }
        return Reply(sb.toString().trim(), calls)
    }

        private suspend fun generate(systemText: String, contents: JSONArray, tools: JSONArray?): Reply = withContext(Dispatchers.IO) {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            return@withContext Reply("API anahtarı bulunamadı. GitHub secret olarak GEMINI_API_KEY eklenmeli.", emptyList(), false)
        }
        fun bodyFor(model: String): String {
            val gen = JSONObject().put("maxOutputTokens", 512)
            // 2.5 ailesi thinkingBudget, 3.x ailesi thinkingLevel ister
            if (model.contains("2.5")) {
                gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            } else if (!model.contains("lite")) {
                gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            }
            val o = JSONObject()
                .put("systemInstruction", JSONObject()
                    .put("parts", JSONArray().put(JSONObject().put("text", systemText))))
                .put("contents", contents)
                .put("generationConfig", gen)
            if (tools != null) o.put("tools", tools)
            return o.toString()
        }

        var lastCode = 0
        var lastErr = ""
        var lastModel = ""
        for (model in order()) {
            var attempt = 0
            while (attempt < 2) {
                attempt++
                try {
                    val (code, text) = call(model, bodyFor(model))
                    lastCode = code
                    lastModel = model
                    if (code in 200..299) { good = model; return@withContext parse(text) }
                    lastErr = runCatching { JSONObject(text).getJSONObject("error").optString("message") }.getOrDefault("")
                    if (code == 401 || code == 403) {
                        return@withContext Reply("API anahtarı reddedildi ($code). Anahtarı kontrol et.", emptyList(), false)
                    }
                    // yoğunluk: aynı modeli bir kez daha dene; diğer hatalarda (404 vb.) hemen sonraki modele geç
                    if ((code == 503 || code == 500) && attempt < 2) { delay(700); continue }
                    penalize(model, code)
                    break
                } catch (e: Exception) {
                    lastCode = -1
                    break
                }
            }
        }
        val detail = " [$lastModel, $lastCode: ${lastErr.take(110)}]"
        val msg = when (lastCode) {
            503, 429 -> "Gemini şu an yanıt vermiyor efendim.$detail"
            -1 -> "İnternet bağlantısında sorun var gibi görünüyor."
            else -> "Gemini'den cevap alamadım.$detail"
        }
        Reply(msg, emptyList(), false)
    }

    private fun userContent(text: String) = JSONArray().put(
        JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))
    )

    /** history: (rol, metin) çiftleri. rol = "user" veya "model" */
    suspend fun chat(history: List<Pair<String, String>>): Reply {
        val contents = JSONArray()
        history.takeLast(20).dropWhile { it.first != "user" }.forEach { (role, text) ->
            contents.put(JSONObject()
                .put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        return generate(system(), contents, TOOLS)
    }

    private const val NEGOTIATOR = "Sen, kullanıcının adına bir ilan veya alışveriş pazarlığını WhatsApp'ta yürüten asistansın. " +
        "Mesajları kullanıcının ağzından, birinci tekil kişiyle, kısa, nazik ve doğal Türkçe yaz (en fazla 1-3 cümle). " +
        "KURALLAR: Kullanıcının tavan fiyatını veya vazgeçme sınırını ASLA açıklama. Tavanın üstünde bir teklifi kabul etme. " +
        "Karşı tarafa gerçekçi, kademeli karşı teklifler yap; baskı, yalan veya tehdit kullanma. " +
        "Kapora, ödeme, IBAN, TC kimlik, adres gibi bilgileri verme veya isteme; kesin satın alma sözü verme, gerekirse 'düşünüp döneceğim' de. " +
        "İlanda olmayan bilgiyi uydurma; bilmediğin bir şey sorulursa 'bakıp döneyim' de. " +
        "Sadece gönderilecek mesajın metnini yaz; açıklama, tırnak veya emoji ekleme. " +
        "Görüşme kesin sonuçlanmışsa (anlaşıldı ya da net ret) yalnızca BİTTİ yaz."

    /** Pazarlıkta sıradaki mesajı önerir. r.ok false ise kullanılmamalı. */
    suspend fun negotiate(brief: String, turns: List<Negotiation.Turn>, note: String?): Reply {
        val sb = StringBuilder("Şu ana kadarki WhatsApp yazışması:\n")
        turns.takeLast(30).forEach { sb.append(if (it.fromMe) "Ben: " else "Karşı taraf: ").append(it.text).append('\n') }
        if (!note.isNullOrBlank()) sb.append("\nKullanıcının bu mesaj için talimatı: ").append(note).append('\n')
        sb.append("\nSıradaki mesajımı yaz.")
        return generate("$NEGOTIATOR\nGörüşme bilgisi ve sınırlar: $brief", userContent(sb.toString()), null)
    }

    /** Sesli okunacak kısa pazarlık raporu. */
    suspend fun report(brief: String, turns: List<Negotiation.Turn>): Reply {
        val sb = StringBuilder("Yazışma:\n")
        turns.takeLast(40).forEach { sb.append(if (it.fromMe) "Ben: " else "Karşı taraf: ").append(it.text).append('\n') }
        val sys = "Sen kullanıcının kişisel asistanısın. Aşağıdaki pazarlık yazışmasını kullanıcıya sesli okunacak şekilde Türkçe, en fazla 5 cümleyle raporla: " +
            "ilk ve son fiyat veya teklif, karşı tarafın şartları (takas, kapora, ekspertiz, evrak vb.), pazarlıkta neyin kabul edildiği veya edilmediği, bir sonraki adım önerin. " +
            "Madde işareti ve markdown kullanma. Yazışmada olmayan bilgiyi uydurma. Kullanıcının hedefi ve sınırı: $brief"
        return generate(sys, userContent(sb.toString()), null)
    }
}
