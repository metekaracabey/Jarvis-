package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class Actions(private val ctx: Context) {
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())

    // Bankacılık ve e-Devlet uygulamalarına erişim kapalı
    private val blocked = listOf(
        "banka", "bank", "e-devlet", "edevlet", "ziraat", "garanti", "akbank", "yapı kredi",
        "yapikredi", "qnb", "denizbank", "enpara", "vakıf", "vakif", "halkbank", "papara",
        "fibabanka", "odeabank", "kuveyt", "albaraka", "tosla", "ininal"
    )

    private data class Contact(val name: String, val number: String)

    suspend fun run(name: String, a: JSONObject): String = when (name) {
        "call_contact" -> call(a.optString("contact_name"), a.optBoolean("speaker", false))
        "send_whatsapp" -> whatsapp(a.optString("contact_name"), a.optString("message"))
        "play_spotify" -> spotify(a.optString("query"))
        "open_app" -> openApp(a.optString("app_name"))
        "get_weather" -> weather()
        "set_alarm" -> alarm(a.optInt("hour"), a.optInt("minute"), a.optString("label"))
        "set_timer" -> timer(a.optInt("seconds"))
        "set_speaker" -> { setSpeaker(a.optBoolean("on", true)); "Tamam efendim." }
        "open_accessibility_settings" -> {
            start(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "Erişilebilirlik ayarlarını açıyorum efendim. Jarvis'i bulup açın."
        }
        else -> "Bu komutu henüz yapamıyorum efendim."
    }

    // ---------------------------------------------------------------- yardımcılar
    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun norm(s: String): String = s.lowercase(Locale("tr", "TR")).map {
        when (it) {
            'ç' -> 'c'; 'ğ' -> 'g'; 'ı' -> 'i'; 'ö' -> 'o'; 'ş' -> 's'; 'ü' -> 'u'
            else -> it
        }
    }.joinToString("").trim()

    private fun intl(n: String): String {
        var d = n.filter { it.isDigit() }
        d = when {
            d.startsWith("00") -> d.drop(2)
            d.startsWith("0") -> "90" + d.drop(1)
            d.length == 10 -> "90$d"
            else -> d
        }
        return d
    }

    private fun findContact(query: String): Contact? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val q = norm(query)
        if (q.isEmpty()) return null
        var best: Contact? = null
        var bestScore = 0
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val n = norm(name)
                val score = when {
                    n == q -> 100
                    n.startsWith(q) -> 80
                    n.contains(q) -> 60
                    q.length > 3 && n.contains(q.dropLast(1)) -> 40
                    q.length > 4 && n.contains(q.dropLast(2)) -> 30
                    else -> 0
                }
                if (score > bestScore) { bestScore = score; best = Contact(name, num) }
            }
        }
        return best
    }

    // ---------------------------------------------------------------- arama
    private fun call(name: String, speaker: Boolean): String {
        if (!granted(Manifest.permission.CALL_PHONE)) return "Telefon izni verilmemiş efendim. Ayarlardan Jarvis'e telefon iznini açar mısınız?"
        if (!granted(Manifest.permission.READ_CONTACTS)) return "Rehber izni verilmemiş efendim."
        val c = findContact(name) ?: return "Rehberde $name adında birini bulamadım efendim."
        val num = c.number.filter { it.isDigit() || it == '+' }
        start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")))
        if (speaker) handler.postDelayed({ setSpeaker(true) }, 2500)
        return "${c.name} aranıyor efendim."
    }

    @Suppress("DEPRECATION")
    private fun setSpeaker(on: Boolean) {
        try { audio.isSpeakerphoneOn = on } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- WhatsApp
    private fun whatsapp(name: String, msg: String): String {
        if (msg.isBlank()) return "Ne yazacağımı anlayamadım efendim."
        if (!granted(Manifest.permission.READ_CONTACTS)) return "Rehber izni verilmemiş efendim."
        val c = findContact(name) ?: return "Rehberde $name adında birini bulamadım efendim."
        val uri = Uri.parse("https://wa.me/${intl(c.number)}?text=${Uri.encode(msg)}")
        val i = Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")
        return try {
            val auto = SendBridge.serviceRunning
            if (auto) SendBridge.arm()
            start(i)
            if (auto) "${c.name} kişisine gönderiyorum efendim."
            else "Mesajı hazırladım ama otomatik gönderme için erişilebilirlik servisini açmam lazım. Şimdilik Gönder tuşuna siz basın. Servisi açmak için bana erişilebilirlik ayarlarını aç deyin."
        } catch (e: ActivityNotFoundException) {
            "WhatsApp yüklü görünmüyor efendim."
        }
    }

    // ---------------------------------------------------------------- Spotify
    private fun spotify(q: String): String {
        if (q.isBlank()) {
            val launch = ctx.packageManager.getLaunchIntentForPackage("com.spotify.music")
                ?: return "Spotify yüklü görünmüyor efendim."
            start(launch)
            handler.postDelayed({
                audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
                audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
            }, 1800)
            return "Spotify açılıyor efendim."
        }
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage("com.spotify.music")
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, q)
        }
        return try {
            start(i)
            "Spotify'da $q açılıyor efendim."
        } catch (e: Exception) {
            try {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q))))
                "Spotify'da $q aranıyor efendim, çalma tuşuna basmanız gerekebilir."
            } catch (e2: Exception) {
                "Spotify yüklü görünmüyor efendim."
            }
        }
    }

    // ---------------------------------------------------------------- uygulama aç
    private fun openApp(label: String): String {
        val refuse = "Güvenlik nedeniyle bankacılık ve e-Devlet uygulamalarına erişimim kapalı efendim."
        val q = norm(label)
        if (q.isEmpty()) return "Hangi uygulamayı açacağımı anlayamadım efendim."
        if (blocked.any { q.contains(it) }) return refuse
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == q }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) }
            ?: return "$label adında bir uygulama bulamadım efendim."
        val lbl = hit.loadLabel(pm).toString()
        val pkg = hit.activityInfo.packageName
        if (blocked.any { norm(lbl).contains(it) || pkg.lowercase().contains(it) }) return refuse
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "$lbl açılamadı efendim."
        start(i)
        return "$lbl açılıyor efendim."
    }

    // ---------------------------------------------------------------- alarm / zamanlayıcı
    private fun alarm(h: Int, m: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Jarvis" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return try {
            start(i)
            "Alarm %02d:%02d için kuruldu efendim.".format(h, m)
        } catch (e: Exception) { "Alarmı kuramadım efendim." }
    }

    private fun timer(sec: Int): String {
        if (sec <= 0) return "Süreyi anlayamadım efendim."
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return try {
            start(i)
            val mn = sec / 60; val sc = sec % 60
            val txt = buildString {
                if (mn > 0) append("$mn dakika ")
                if (sc > 0) append("$sc saniye")
            }.trim()
            "$txt için zamanlayıcı kuruldu efendim."
        } catch (e: Exception) { "Zamanlayıcıyı kuramadım efendim." }
    }

    // ---------------------------------------------------------------- hava durumu
    @SuppressLint("MissingPermission")
    private fun lastLocation(): Location? {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
    }

    private fun wmo(code: Int) = when (code) {
        0 -> "açık"
        1, 2 -> "parçalı bulutlu"
        3 -> "kapalı"
        45, 48 -> "sisli"
        51, 53, 55, 56, 57 -> "çiseleyen yağmurlu"
        61, 63, 65, 66, 67 -> "yağmurlu"
        71, 73, 75, 77, 85, 86 -> "karlı"
        80, 81, 82 -> "sağanak yağışlı"
        95, 96, 99 -> "gök gürültülü fırtınalı"
        else -> "değişken"
    }

    private suspend fun weather(): String {
        val loc = lastLocation()
            ?: return "Konumunuza erişemedim efendim. Konum izni ve konum servisi açık olmalı."
        return withContext(Dispatchers.IO) {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
                        "&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000; readTimeout = 10000
                }
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val cur = JSONObject(txt).getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val wind = Math.round(cur.getDouble("wind_speed_10m")).toInt()
                val desc = wmo(cur.getInt("weather_code"))
                val place = try {
                    @Suppress("DEPRECATION")
                    Geocoder(ctx, Locale("tr", "TR")).getFromLocation(loc.latitude, loc.longitude, 1)
                        ?.firstOrNull()?.let { it.subAdminArea ?: it.locality }
                } catch (e: Exception) { null }
                val where = place ?: "Bulunduğunuz yerde"
                "$where şu an hava $desc, sıcaklık $t derece, rüzgar saatte $wind kilometre."
            } catch (e: Exception) {
                "Hava durumunu alamadım efendim."
            }
        }
    }
}
