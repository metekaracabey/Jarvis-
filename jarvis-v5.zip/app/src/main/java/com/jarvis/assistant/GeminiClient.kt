package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GeminiClient {
    // Sırayla denenir: biri yoğunsa veya kapalıysa sonrakine geçilir
    private val MODELS = listOf("gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash")

    data class Reply(val text: String, val calls: List<Pair<String, JSONObject>>)

    private const val SYSTEM = "Sen JARVIS adlı kişisel yapay zeka asistanısın ve kullanıcının telefonunu kontrol eden araçların var. " +
        "Türkçe konuş. Cevapların sesli okunacak: kısa, net, doğal ve hafif zeki bir tonda ol (en fazla 2-3 cümle). " +
        "Liste, madde işareti, emoji ve markdown kullanma. Kullanıcıya 'efendim' diye hitap edebilirsin ama abartma. " +
        "Kullanıcı bir işlem isterse (arama, mesaj, müzik, uygulama açma, hava durumu, alarm, zamanlayıcı) ilgili aracı MUTLAKA çağır, " +
        "'yapamam' deme. Kişi adlarını rehberde kayıtlı olabileceği yalın biçimde ver ('babama' -> 'babam', 'Ahmet'e' -> 'Ahmet'). " +
        "WhatsApp mesajını kullanıcının ağzından, birinci tekil kişiyle yaz: 'babama neredesin yaz' -> mesaj 'Neredesin?'. " +
        "Banka ve e-Devlet işlemleri yapma. Araç gerektirmeyen sorularda normal sohbet et."

    private fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    private fun fn(name: String, desc: String, props: JSONObject = JSONObject(), required: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.length() > 0) {
            o.put("parameters", JSONObject()
                .put("type", "object")
                .put("properties", props)
                .put("required", JSONArray(required)))
        }
        return o
    }

    private val TOOLS: JSONArray = JSONArray().put(
        JSONObject().put("functionDeclarations", JSONArray()
            .put(fn("call_contact", "Rehberdeki birini arar.",
                JSONObject()
                    .put("contact_name", p("string", "Rehberdeki kişi adı, yalın hâl"))
                    .put("speaker", p("boolean", "Hoparlöre alınsın mı")),
                listOf("contact_name")))
            .put(fn("send_whatsapp", "Rehberdeki birine WhatsApp mesajı gönderir.",
                JSONObject()
                    .put("contact_name", p("string", "Rehberdeki kişi adı, yalın hâl"))
                    .put("message", p("string", "Gönderilecek mesaj metni")),
                listOf("contact_name", "message")))
            .put(fn("play_spotify", "Spotify'da şarkı, sanatçı veya çalma listesi açıp çalar. Sadece 'müzik aç' denirse query boş olsun.",
                JSONObject().put("query", p("string", "Aranacak sanatçı veya şarkı"))))
            .put(fn("open_app", "Telefondaki bir uygulamayı açar.",
                JSONObject().put("app_name", p("string", "Uygulamanın adı")), listOf("app_name")))
            .put(fn("get_weather", "Kullanıcının bulunduğu konumun güncel hava durumunu söyler."))
            .put(fn("set_alarm", "Belirli bir saate alarm kurar.",
                JSONObject()
                    .put("hour", p("integer", "Saat, 0-23"))
                    .put("minute", p("integer", "Dakika, 0-59"))
                    .put("label", p("string", "Alarm adı")),
                listOf("hour", "minute")))
            .put(fn("set_timer", "Geri sayım zamanlayıcısı kurar.",
                JSONObject().put("seconds", p("integer", "Toplam süre, saniye")), listOf("seconds")))
            .put(fn("set_speaker", "Devam eden aramada hoparlörü açar veya kapatır.",
                JSONObject().put("on", p("boolean", "Açık mı")), listOf("on")))
            .put(fn("open_accessibility_settings", "Erişilebilirlik ayarlarını açar, WhatsApp otomatik gönderme servisini açmak için."))
        )
    )

    private fun system(): String {
        val now = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", Locale("tr", "TR")).format(Date())
        return "$SYSTEM Şu an tarih ve saat: $now."
    }

    private fun call(model: String, body: String): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun parse(text: String): Reply {
        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").optJSONArray("parts") ?: return Reply("", emptyList())
        val sb = StringBuilder()
        val calls = mutableListOf<Pair<String, JSONObject>>()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            part.optJSONObject("functionCall")?.let {
                calls.add(it.getString("name") to (it.optJSONObject("args") ?: JSONObject()))
            }
            if (part.has("text")) sb.append(part.getString("text"))
        }
        return Reply(sb.toString().trim(), calls)
    }

    /** history: (rol, metin) çiftleri. rol = "user" veya "model" */
    suspend fun chat(history: List<Pair<String, String>>): Reply = withContext(Dispatchers.IO) {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            return@withContext Reply("API anahtarı bulunamadı. GitHub secret olarak GEMINI_API_KEY eklenmeli.", emptyList())
        }
        val contents = JSONArray()
        history.takeLast(20).forEach { (role, text) ->
            contents.put(JSONObject()
                .put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject()
                .put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("tools", TOOLS)
            .put("generationConfig", JSONObject()
                .put("thinkingConfig", JSONObject().put("thinkingLevel", "low")))
            .toString()

        var lastCode = 0
        for (model in MODELS) {
            repeat(2) { attempt ->
                try {
                    val (code, text) = call(model, body)
                    lastCode = code
                    if (code in 200..299) return@withContext parse(text)
                    if (code == 401 || code == 403) {
                        return@withContext Reply("API anahtarı reddedildi ($code). Anahtarı kontrol et.", emptyList())
                    }
                    if ((code == 503 || code == 429) && attempt == 0) delay(1500) else return@repeat
                } catch (e: Exception) {
                    lastCode = -1
                    return@repeat
                }
            }
        }
        val msg = when (lastCode) {
            503, 429 -> "Gemini şu an çok yoğun, birkaç saniye sonra tekrar dener misin efendim?"
            -1 -> "İnternet bağlantısında sorun var gibi görünüyor."
            else -> "Gemini'den cevap alamadım (hata $lastCode)."
        }
        Reply(msg, emptyList())
    }
}
