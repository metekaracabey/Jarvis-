package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    // Sırayla denenir: biri yoğunsa veya kapalıysa sonrakine geçilir
    private val MODELS = listOf("gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash")

    private const val SYSTEM = "Sen JARVIS adlı kişisel yapay zeka asistanısın. " +
        "Türkçe konuş. Cevapların sesli okunacak: kısa, net, doğal ve hafif zeki bir " +
        "tonda ol (en fazla 2-3 cümle). Liste, madde işareti, emoji ve markdown kullanma. " +
        "Kullanıcıya 'efendim' diye hitap edebilirsin ama abartma."

    private fun call(model: String, body: String): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    /** history: (rol, metin) çiftleri. rol = "user" veya "model" */
    suspend fun chat(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            return@withContext "API anahtarı bulunamadı. GitHub secret olarak GEMINI_API_KEY eklenmeli."
        }
        val contents = JSONArray()
        history.takeLast(20).forEach { (role, text) ->
            contents.put(JSONObject()
                .put("role", role)
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject()
                .put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject()
                .put("thinkingConfig", JSONObject().put("thinkingLevel", "low")))
            .toString()

        var lastCode = 0
        for (model in MODELS) {
            repeat(2) { attempt ->
                try {
                    val (code, text) = call(model, body)
                    lastCode = code
                    if (code in 200..299) {
                        return@withContext JSONObject(text)
                            .getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts")
                            .getJSONObject(0).getString("text").trim()
                    }
                    // 401/403: anahtar sorunu, denemenin anlamı yok
                    if (code == 401 || code == 403) {
                        return@withContext "API anahtarı reddedildi ($code). Anahtarı kontrol et."
                    }
                    // 503/429: kısa bekle, aynı modeli bir kez daha dene
                    if ((code == 503 || code == 429) && attempt == 0) delay(1500) else return@repeat
                } catch (e: Exception) {
                    lastCode = -1
                    return@repeat
                }
            }
        }
        when (lastCode) {
            503, 429 -> "Gemini şu an çok yoğun, birkaç saniye sonra tekrar dener misin efendim?"
            -1 -> "İnternet bağlantısında sorun var gibi görünüyor."
            else -> "Gemini'den cevap alamadım (hata $lastCode)."
        }
    }
}
